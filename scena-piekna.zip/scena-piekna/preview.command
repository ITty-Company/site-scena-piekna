#!/bin/bash
cd "$(dirname "$0")" && (sleep 1; open http://localhost:7799/index.html) & python3 -m http.server 7799
